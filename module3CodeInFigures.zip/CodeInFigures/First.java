public class First
{
   public static void main(String[] args)
   {
      nameAndAddress();
      System.out.println("First Java application");
   }
   public static void nameAndAddress()
   {
      System.out.println("XYZ Company");
      System.out.println("8900 U.S. Hwy 14");
      System.out.println("Crystal Lake, IL 60014");
   }
}
