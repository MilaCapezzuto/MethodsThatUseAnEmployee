public class MyClass
{
    public static void pubStatMethod()
    {
        System.out.println("I am a pubSatMethod");
    }
    private static void privStatMethod()
    {
        System.out.println("I am a pubStatMethod");
    }
            
    public void pubNonStatMethod()
    {
        System.out.println("I am a pubStatMethod");
    }
    private void privNonstatMethod()
    {
        System.out.println("I am a private Non Static Method");
    }
}