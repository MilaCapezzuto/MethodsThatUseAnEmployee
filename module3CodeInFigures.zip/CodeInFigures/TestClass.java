/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WJING0001
 */
public class TestClass {
    public static main(String[] args)
    {
        MyClass myObject = new MyClass();
        myObject.pubNonStatMethod();
        myObject.pubStatMethod();
        MyClass.pubStatMethod();
    
        //None of the following work
        //MyClass.privStatMethod();
        //MyClass.pubNonstatMethod();
        //myObject.privStatMethod();
        //myObject.privNonstatMethod();
        //MyClass.privNonstatMethod();
    }
}
